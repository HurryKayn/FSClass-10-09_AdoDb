﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using static System.Net.Mime.MediaTypeNames;

namespace ADOes01.adoDb
{
    internal class AdoDb
    {
        private string GetCon()
        {
            string con = "Data Source=WIN10-2023-08-2; Initial Catalog=Negozio; Integrated Security=True;";
            //string con  = "Data Source=WIN10-2023-08-2;Initial Catalog=Negozio;Integrated Security=True;";
            return con;
        }
        public void ClientiUpdate()
        {
            try
            { 

                SqlTransaction tr = null;
                using (SqlConnection connection = new SqlConnection(GetCon()))
                {
                    connection.Open();
                    Console.WriteLine("Avvia Transaction");
                    
                    try
                    {
                        tr = connection.BeginTransaction();
                        
                        {   //-- questo comando è corretto e quindi potrebbe aggiorare il record
                            //-- cosa che avviene se non è interno alla transaction
                            string query = "UPDATE Clienti Set Nome='Fausto' where ClienteID = 1";
                            SqlCommand cmd = new SqlCommand(query, connection);
                            cmd.Transaction = tr;
                            
                             cmd.ExecuteNonQuery();
                        }

                        {//.. genera errore in quanto ZonaID 14 non esiste e su questa è iumpostata forign key
                         //-- se i comandi di update sono inseriti in una transaction nessu aggiornamento viene eseguito in quanto 
                         //-- in catch chiudo la transazione con un rollback.
                         //-- se invece di rollback eseguisse commit il comando precende verrebbe memorizzato du DB
                            string query = "UPDATE Clienti Set ZonaID='2' where ClienteID = 4";
                            SqlCommand cmd = new SqlCommand(query, connection);
                            cmd.Transaction = tr;
                            int i = cmd.ExecuteNonQuery();
                        }


                        {   //-- codice corretto ma non è mai raggiunto in quanto si verifica precedentemente un erroe
                            string query = "UPDATE Clienti Set Nome='Ugo' where ClienteID = 3";
                            SqlCommand cmd = new SqlCommand(query, connection);
                            cmd.Transaction = tr;
                            int i = cmd.ExecuteNonQuery();
                        }
                      tr.Commit();
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Intervcetta errore, esegue Rollback");
                        tr.Rollback();

                    }


                }
            }
            catch (Exception e)
            {

                //throw;
            }

        }
        public void ClientiRead()
        {
            try
            {
                using (SqlConnection connection  =new SqlConnection(GetCon()))
                {
                    connection.Open();
                    string query = "SELECT nome,Cognome,EMail FROM Clienti WHERE Cognome >='G' ORDER BY Cognome";
                    
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                       SqlDataReader  reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            string nome = reader["Nome"].ToString();
                            string cognome = reader["Cognome"].ToString();
                            string email = reader["email"].ToString();
                            //-- costruzione stringa da mandare in stampa
                            //string s = "Nome Cliente: " + nome + " Cognome: " + cognome;
                            string output = $"Nome Cliente: {nome} Cognome: {cognome} email: {email}";
                            Console.WriteLine(output);
                        }
                    }
                    
                }
            }
            catch (Exception e)
            {

                Console.WriteLine(e.Message);
            }
        }
        public void ClientiRead_Normale()
        {
            //* Creazione oggetto di Connessione
            SqlConnection con = new SqlConnection(GetCon());
            try
            {
                //* Apertura Connessione
                con.Open();
                /*
                 * codice per lettra dati du Db
                */

            }
            catch (Exception e )
            {

            }
            finally
            {
                con.Close();
            }
            
        }
    }
}
