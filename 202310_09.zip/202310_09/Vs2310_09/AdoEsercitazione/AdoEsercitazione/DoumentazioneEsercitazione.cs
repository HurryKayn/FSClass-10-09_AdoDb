﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace AdoEsercitazione
//{
//    internal class DoumentazioneEsercitazione
//    {
//    }
//}
/*
 * eseguiamo inserimento di un cliente 
 * Fabio Rossi Fabio.Rossi@yahoo.it zonaId =3;
 * INNER JOIN clienti con zone
 * 
 * select solo clienti con zona compresa tra 2 e 4
 * 
 * writeline(nome, cognome, 'nome della zona')
 * 
 * 
 * ------------------------------------------
 * Join Ordini
 * nome del cliente, cognome cliente, nome prodotto
 * 
 * ------------------------------------------ esercizio datra insert
 * tabella categorie
 * s=console.ReadLine()
 * if s='.' allora applicazione termina ed esegue commit
 * if s='-' allora applicazione termina ed esegue rollback
 * if s='' allora richiede ancora categoria
 * altrimenti insert della la categoria letta con readLine 
 * (ma insert non definitivo, serve commit per chiudere transazione)
 * 
 */