﻿using AdoEsercitazione.ADOes01.adoDb;

namespace AdoEsercitazione
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var ado = new AdoDb();
            //ado.ClientiInsert();
            //ado.ClientiRead();
            // ado.GetOrdiniAll();
            ado.InsertCategorie();
            Console.WriteLine("********************************");
            Console.WriteLine("Applicazione Terminata");
        }
    }
}