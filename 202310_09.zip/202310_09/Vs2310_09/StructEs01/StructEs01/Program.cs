﻿namespace StructEs01
{
    internal class Program
    {
        struct Coordinate
        {
            public int X;
            public int Y;

            //public int XR { get; init; }
            //public int YR { get; init; }

            public Coordinate()
            {
                X = 0;
                Y = 0;
                //XR = 0;
                //YR = 0;
            }

            public Coordinate (int x, int y)
            {
                X = x; Y = y;   
            }

        }
        
        static void Main(string[] args)
        {


            Coordinate c3 = new Coordinate(10,13);
            Coordinate c2 = c3;
            c2.X = 1;
            c2.Y = 2;
            Console.WriteLine(c3.X);
            Console.WriteLine(c3.Y);
            Console.WriteLine(c2.X);
            Console.WriteLine(c2.Y);
        }
    }
}