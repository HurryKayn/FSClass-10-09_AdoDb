Use Negozio;
CREATE TABLE Categorie (
    CategoriaID INT PRIMARY KEY IDENTITY(1,1),
    Nome NVARCHAR(100),
    
);

-- Inseriamo alcune categorie di esempio
INSERT INTO Categorie (Nome)
VALUES 
('Mobili'),('Elettrodomestici'),('Accessori');