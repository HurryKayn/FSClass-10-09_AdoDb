INSERT INTO Prodotti 
(Nome, Prezzo)
VALUES
('Tavolo',120),
('Sedia',40),
('Frigorifero',320),
('Forno',150),
('Lavatrice',450),
('Tovaglia',12);