use negozio;
CREATE TABLE Zone (
    ZonaID INT PRIMARY KEY IDENTITY(1,1),
    NomeZona NVARCHAR(100),
    Descrizione NVARCHAR(255)
);
INSERT INTO Zone (NomeZona, Descrizione)
VALUES 
('Nord', 'Zona settentrionale della citt�'),
('Sud', 'Zona meridionale della citt�'),
('Est', 'Zona orientale della citt�'),
('Ovest', 'Zona occidentale della citt�');