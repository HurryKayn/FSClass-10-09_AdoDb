--- Creazione Database
IF NOT EXISTS(
	SELECT name
	FROM master.dbo.sysdatabases
	WHERE name = N'Negozio'
) CREATE DATABASE Negozio;

USE Negozio;
IF NOT EXISTS (
	select Name
	FROM sysobjects
	WHERE Name='Clienti'
	AND xtype ='U') -- S = tabella di sistema; V = Vista; P StoredProcedure; TR Trigger

		CREATE TABLE Clienti(
		ClienteID  INT IDENTITY (1,1) PRIMARY KEY,
		Nome nvarchar(100) not null,
		Cognome nvarchar(100) not null,
		email nvarchar(100)
	);

IF NOT EXISTS (
	select Name
	FROM sysobjects
	WHERE Name='Prodotti'
	AND xtype ='U') -- S = tabella di sistema; V = Vista; P StoredProcedure; TR Trigger

CREATE TABLE prodotti (
		ProdottoID  INT IDENTITY (1,1) PRIMARY KEY,
		Nome nvarchar(100) not null,
		Prezzo decimal (10,2)
	);

IF NOT EXISTS (
	select Name
	FROM sysobjects
	WHERE Name='Ordini'
	AND xtype ='U') -- S = tabella di sistema; V = Vista; P StoredProcedure; TR Trigger
CREATE TABLE Ordini(
	OrdineID  INT IDENTITY (1,1) PRIMARY KEY,
	ClienteID INT FOREIGN KEY REFERENCES Clienti(ClienteID),
	ProdottoID INT FOREIGN KEY REFERENCES Prodotti(ProdottoID),
	DataOrdine DATE,
	Quantita INT,
	ImportoDiRIga DECIMAL (13,2)
);