INSERT INTO Clienti 
(Nome, Cognome,Email)
VALUES
('Mario','Rossi','Mario.Rossi@gmail.com'),
('Luca','Verdi','Luca.Verdi@gmail.com'),
('Anna','Salmo','Anna.Salmo@gmail.com'),
('Roberta','Giusti','Roberta.Giusti@gmail.com'),
('Carlo','Antogni','Carlo.Antogni@gmail.com'),
('Sabrina','Ferri','Sabrina.Ferri@gmail.com');

