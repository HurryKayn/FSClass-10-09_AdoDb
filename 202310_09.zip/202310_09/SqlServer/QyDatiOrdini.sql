INSERT INTO Ordini
(ClienteID,ProdottoID,DataOrdine,Quantita,ImportoDiRIga)
VALUES
(1,1,GETDATE(),10,1200),
(3,4,GETDATE(),1,150),
(1,2,GETDATE(),20,800)
