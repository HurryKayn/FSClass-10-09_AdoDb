BEGIN TRANSACTION;  -- Inizio della transazione

BEGIN TRY
    -- Inseriamo dei dati nella tabella Clienti
   

    -- Inseriamo dei dati nella tabella Ordini
    INSERT INTO Ordini (ClienteID, ProdottoID, DataOrdine,Quantita)
    VALUES (2,3, GETDATE(),9);

	INSERT INTO Ordini (ClienteID, ProdottoID, DataOrdine,Quantita)
    VALUES (1,1, GETDATE(),13);

	INSERT INTO Ordini (ClienteID, ProdottoID, DataOrdine,Quantita)
    VALUES (4,1, GETDATE(),4);

	INSERT INTO Ordini (ClienteID, ProdottoID, DataOrdine,Quantita)
    VALUES (14,1, GETDATE(),2);
    COMMIT;  -- Se tutto va bene, confermiamo le operazioni
END TRY
BEGIN CATCH
    ROLLBACK;  -- In caso di errore, annulliamo le operazioni
    -- Gestione dell'errore (e.g., log, notifica, etc.)
    PRINT 'Errore Gestito: ' + ERROR_MESSAGE();
END CATCH;
