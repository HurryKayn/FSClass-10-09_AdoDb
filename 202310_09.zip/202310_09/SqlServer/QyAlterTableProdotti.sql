use negozio;
ALTER TABLE Prodotti
ADD CategoriaID INT;

ALTER TABLE Prodotti
ADD CONSTRAINT FK_Prodotti_Categorie
FOREIGN KEY (CategoriaID) REFERENCES Categorie(CategoriaID);