UPDATE Prodotti
SET CategoriaID = 1
WHERE Nome IN ('Tavolo', 'Sedia');

UPDATE Prodotti
SET CategoriaID = 2
WHERE Nome IN ('Frigorifero', 'Forno','Lavatrice');

UPDATE Prodotti
SET CategoriaID = 3
WHERE Nome = 'Tovaglia';



Update Clienti
SET ZonaID = 1 WHERE ClienteID = 1;

Update Clienti
SET ZonaID = 2 WHERE ClienteID = 2;

Update Clienti
SET ZonaID = 3 WHERE ClienteID = 3;

Update Clienti
SET ZonaID = 4 WHERE ClienteID = 4;

Update Clienti
SET ZonaID = 1 WHERE ClienteID = 5;

Update Clienti
SET ZonaID = 2 WHERE ClienteID = 6;